# myapp/importer.py
import csv
from django.contrib.auth.models import User
from myapp.models import Teacher

def import_teachers(csv_file_path):
    with open(csv_file_path, 'r') as file:
        csv_reader = csv.DictReader(file)
        for row in csv_reader:
            # Assuming the CSV columns are: first_name, last_name, email, phone_number, room_number
            teacher_data = {
                'first_name': row['first_name'],
                'last_name': row['last_name'],
                'email': row['email'],
                'phone_number': row['phone_number'],
                'room_number': row['room_number'],
            }
            teacher, created = Teacher.objects.get_or_create(email=row['email'], defaults=teacher_data)


            subjects = row.get('subjects', '').split(',')
            teacher.subjects_taught.set(subjects)

if __name__ == '__main__':

    csv_file_path = 'path/to/your/csv/file.csv'
    import_teachers(csv_file_path)
