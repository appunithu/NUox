from django.db import models

# Create your models here.
from django.db import models

class Teacher(models.Model):
    firstname = models.CharField(max_length=255)
    lastname = models.CharField(max_length=255)
    profilepicture = models.ImageField(upload_to='profile_pics/', default='profile_pics/default.jpg')
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=15)
    room_number = models.CharField(max_length=10)
    subjects_taught = models.ManyToManyField('Subject', related_name='teachers')

class Subject(models.Model):
    name = models.CharField(max_length=255, unique=True)
