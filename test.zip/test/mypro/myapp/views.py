from django.shortcuts import render

from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404, redirect
from .models import Teacher
from .forms import TeacherForm

def teacher_list(request):
    teachers = Teacher.objects.all()
    return render(request, 'myapp/teacher_list.html', {'teachers': teachers})

def teacher_detail(request, teacher_id):
    teacher = get_object_or_404(Teacher, pk=teacher_id)
    return render(request, 'myapp/teacher_detail.html', {'teacher': teacher})

def add_teacher(request):
    if request.method == 'POST':
        form = TeacherForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('teacher_list')
    else:
        form = TeacherForm()
    return render(request, 'myapp/teacher_form.html', {'form': form, 'action': 'Add'})

def edit_teacher(request, teacher_id):
    teacher = get_object_or_404(Teacher, pk=teacher_id)
    if request.method == 'POST':
        form = TeacherForm(request.POST, instance=teacher)
        if form.is_valid():
            form.save()
            return redirect('teacher_list')
    else:
        form = TeacherForm(instance=teacher)
    return render(request, 'myapp/teacher_form.html', {'form': form, 'action': 'Edit', 'teacher': teacher})

def filter_teachers(request):
    if request.method == 'POST':
        letter = request.POST.get('letter')
        subject = request.POST.get('subject')
        if letter:
            teachers = Teacher.objects.filter(last_name__istartswith=letter)
        elif subject:
            teachers = Teacher.objects.filter(subjects_taught__name=subject)
        else:
            teachers = Teacher.objects.all()
        return render(request, 'myapp/teacher_list.html', {'teachers': teachers})
    return redirect('teacher_list')

def filter_teachers_ajax(request):
    if request.method == 'POST':
        letter = request.POST.get('letter')
        subject = request.POST.get('subject')
        if letter:
            teachers = Teacher.objects.filter(lastname__istartswith=letter)
        elif subject:
            teachers = Teacher.objects.filter(subjects_taught__name=subject)
        else:
            teachers = Teacher.objects.all()

        data = {
            'teachers': [{'id': teacher.id, 'name': f'{teacher.first_name} {teacher.last_name}'} for teacher in teachers]
        }

        return JsonResponse(data)
    return JsonResponse({'error': 'Invalid request'})
