from django.contrib import admin

from .models import Subject,Teacher
from .views import *
# Register your models here.
admin.site.register(Teacher)
admin.site.register(Subject)